

<?php $__env->startSection('content'); ?>

<div class = "container">

    <h3> 
        Daftar Buku
        <a class="btn btn-primary btn-sm float-end" href="<?php echo e(url('buku/create')); ?>">Tambah Data</a>
    </h3>

    <table class ="table table-bordered">
        <tr>
            <th>NO</th>
            <th>KODE</th>
            <th>JUDUL</th>
            <th>TERBIT</th>
            <th>EDIT</th>
            <th>DELETE</th>
        </tr>
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($row->buku_id); ?></td>
        <td><?php echo e($row->buku_kode); ?></td>
        <td><?php echo e($row->buku_judul); ?></td>
        <td><?php echo e($row->buku_terbit); ?></td>
        <td><a href="<?php echo e(url('buku/' . $row->buku_id . '/edit')); ?>">Edit</a></td>
                    <td>
                        <form action="<?php echo e(url('buku/' . $row->buku_id)); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button>Hapus</button>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-uas-am\resources\views/buku/index.blade.php ENDPATH**/ ?>